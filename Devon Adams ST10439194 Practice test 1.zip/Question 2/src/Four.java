import java.util.Arrays;
public class Four {
    int[] StrArr = [50];
    for(int i = 0; 1 <StrArr.length; i++) {

        System.out.println(StrArr[50] + ":");

    }

}
