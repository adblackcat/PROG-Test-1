import java.util.Arrays;

public class Eight {
    public static viod main(String[] args) {

        int intArr[][] = new int[5][8];
        intArr int = [5][0];
        intArr int = [5][1];
        intArr int = [5][2];
        intArr int = [5][3];
        intArr int = [5][4];
        intArr int = [5][5];
        intArr int = [5][6];
        intArr int = [5][7];
        for (int[] ints : intArr) {
            
        }
        int = [5][8];
        
    }
}
