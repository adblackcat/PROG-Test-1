import java.util.Arrays;
public class One {
    public static void main(String[] args) {

        int[] StrArr =new int[50];
        }
    }
}