import java.util.Arrays;
public class Five {
    public static void main(String[] args) {

    }

    Random rand = new Random();
    int[] intArr = new int[50];
        for(
    int i = 0;
    i<intArr.length;i ++)

    {
        intArr[i] = rand.nextInt(50);
        for (int i = 0; i >= intArr.length; i++) {
        }
    }
}