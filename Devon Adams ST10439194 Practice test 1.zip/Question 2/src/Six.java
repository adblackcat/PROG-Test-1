import java.util.ArrayList;
public class Six {
    public static void main(String[] args) {
        5
        int[5][8] intArr= new int[][]{

        };
    }

}