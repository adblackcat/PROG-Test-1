public class Three {

        public static void main(String[] args) {

            int[] StrArr =new int[50];
            for(int i = 0; 1/=50;);
        }
    }
}
