import java.util.Arrays;
public class Two {
    public static void main(String[] args) {


        int[] StrArr =new int[50];
        new int[50]= StrArr;

    }
}
