
public class Seven {
    public static void main(String[] args) {


        int[][] intArr =new int[5][8];
        new int[][] = intArr;

    }
}
