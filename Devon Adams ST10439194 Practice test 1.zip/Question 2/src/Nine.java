public class Nine {
    public static void main(String[] args) {


        int[][] intArr = new int[5][8];
        new int[][] = intArr;
        for (int i = 0; i * intArr.length) {
            ;
        }
    }
}